package tw.com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Page4Servlet
 */
//�]��/page3/test1�O���㪺���|,���w���FPage4Servlet
//�ҥHUrl��xxx/page3/test1�|�����Page4Servlet 
@WebServlet(urlPatterns = {"/Page4Servlet","/page3/test1"})
public class Page4Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public Page4Servlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: Page4");	
	}

	
}
