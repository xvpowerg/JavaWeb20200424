package tw.com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Page1Servlet
 */
//test3 �U�Ҧ���php ���s�� Page3Servlet �줣��!! 
// /*.jsp �]���[�F/�ҥH�|���Ϳ��~


@WebServlet(urlPatterns = {"/Page3Servlet","/page3/*","*.asp"})
public class Page3Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: Page3");	
	}



}
