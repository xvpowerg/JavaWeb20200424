package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.bean.Food;

/**
 * Servlet implementation class ShowPagServlet
 */
@WebServlet("/ShowPagServlet")
public class ShowPagServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//�ݩʭn�p�ߨϥ� �i��|��������m�������D
	private List<Food> foodList = new ArrayList<>();
   //�i�ΨӪ�l��PagServlet���ݩ�
   //�u�|�I�s�@��
	public void init() {
		Food f1 = new Food("���L��",90);
		Food f2 = new Food("�ư���",75);
		Food f3 = new Food("�޸}��",85);
		foodList.add(f1);
		foodList.add(f2);
		foodList.add(f3);
	}
    public ShowPagServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//�]��Servlet�O�bThread���B��ҥH�������@�ӷs��List�P�s��Food
		List<Food>	newFoodList = Food.getFoodList();
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<meta charset='UTF-8'>");
		out.println("</head>");
		out.println("<body>");
		String name = request.getParameter("myName");
		  out.println("<H3>�q�ʤH:"+name+"</H3>");
		   String[] foods = 
				    request.getParameterValues("food");
		   for(String v : foods) {
			   String countStr =  
					   request.getParameter("count"+v);
			  int index =  Integer.parseInt(v);
			  Food food =   newFoodList.get(index);
			  food.setCount(countStr);
			   out.println("<p>�~�W:"+food.getName()+
					   " �ƶq:"+food.getCount()+
					    "���B:"+food.getPrice()+"X"+
					     food.getCount()+"="+food.getTotal()+"</p>");
		   }
		   
		  for(Food f : newFoodList) {
			  System.out.println("Food:"+f);
		  }
		out.println("</body>");
		out.println("</html>");
		
	}

}
