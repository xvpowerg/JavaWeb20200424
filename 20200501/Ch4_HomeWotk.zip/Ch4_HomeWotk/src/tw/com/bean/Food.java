package tw.com.bean;

import java.util.ArrayList;
import java.util.List;

public class Food {
	private String name;
	private int price;
	private int count;

	public Food(String name, int price) {
		super();
		this.name = name;
		this.price = price;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public void setCount(String count) {
		int intCount = 0;
		try {
		   intCount = Integer.parseInt(count);
		}catch(Exception ex) {
			
		}
		this.count = intCount;
	}

	public int getTotal() {
		return count * price;
	}
	
	@Override
	public String toString() {
		return "Food [name=" + name + ", price=" + price + ", count=" + count + "]";
	}
	
	public static List<Food> getFoodList(){
		List<Food> foodList = new ArrayList<>();
		Food f1 = new Food("���L��",90);
		Food f2 = new Food("�ư���",75);
		Food f3 = new Food("�޸}��",85);
		foodList.add(f1);
		foodList.add(f2);
		foodList.add(f3);
		return foodList;
	}
	
}
