package tw.com.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

/**
 * Servlet Filter implementation class BFilterTestOder
 */
//�p�G�ϥε��ѫإߪ�Filter�L���涶��
//��Filter�X�Ӫ����ǬO���i��X
@WebFilter("/TestOrderSservlet1")
public class DFilterTestOder implements Filter {
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		System.out.println("In DFilterTestOder");
		chain.doFilter(request, response);
		System.out.println("out DFilterTestOder");
	}
}
