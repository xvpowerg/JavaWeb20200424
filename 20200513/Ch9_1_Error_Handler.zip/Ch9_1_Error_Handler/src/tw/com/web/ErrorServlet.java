package tw.com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ErrorServlet
 */
@WebServlet("/ErrorServlet")
public class ErrorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ErrorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    
    private void testError(HttpServletRequest request,
    		HttpServletResponse response) throws ServletException, IOException {
    	System.out.println("testError");
    	Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
    	switch(statusCode) {
    	case 404:
    		request.setAttribute("image", "error404.png");
    		break;
    	case 405:
    		request.setAttribute("image", "error.png");
    		break;
        default:
        	Exception ex=(Exception)request.
        	getAttribute("javax.servlet.error.exception");
        	System.out.println(ex);
        	request.setAttribute("image", "image1.jpg");
        	break;
    	}
    	request.getRequestDispatcher("/ErrorPage.jsp").
    	        forward(request, response);
    	
    }
    
	
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		testError(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		testError(request,response);
	}

}
