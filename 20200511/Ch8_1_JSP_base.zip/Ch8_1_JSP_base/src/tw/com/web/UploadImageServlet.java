package tw.com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.InputStream;
import java.util.List;
import java.io.FileOutputStream;
import tw.com.tools.IoTools;

/**
 * Servlet implementation class UploadImage
 */
//@MultipartConfig �i�ϥ�Java�u��W�� 
@MultipartConfig
@WebServlet("/UploadImageServlet")
public class UploadImageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public UploadImageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		String imageFilePath = 
				getServletContext().getInitParameter("imageFilePath");

		Part photo= request.getPart("photo");
		String fileName =   photo.getSubmittedFileName();
		imageFilePath+=fileName;
	
		//�@�~��o���ܦ�model
		try(InputStream  in = photo.getInputStream();
			FileOutputStream out = new FileOutputStream(imageFilePath)){
			
			byte[] buffer = new byte[1024];
			int index = -1;
			while ( (index = in.read(buffer)) !=-1 ) {
				out.write(buffer,0,index);
			}
		}
		
		// imageList �ϥ�Applaction�Ǩ�showImage2.jsp �����
		List<String> imageList = IoTools.readFileNames(imageFilePath);

		
	}

}
