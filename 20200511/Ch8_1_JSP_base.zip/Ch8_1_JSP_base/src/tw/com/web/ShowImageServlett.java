package tw.com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.com.tools.IoTools;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.nio.file.Files;
/**
 * Servlet implementation class ShowImageServlett
 */
@WebServlet("/ShowImageServlett")
public class ShowImageServlett extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public ShowImageServlett() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String imageFilePath = 
				getServletContext().getInitParameter("imageFilePath");

	    List<String> imageList = IoTools.readFileNames(imageFilePath);
		
	    HttpSession session = request.getSession();
		session.setAttribute("imageList", imageList);
		response.sendRedirect("ImageView.jsp");
	}
}
