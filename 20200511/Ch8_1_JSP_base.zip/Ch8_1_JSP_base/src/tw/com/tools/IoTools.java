package tw.com.tools;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.nio.file.Files;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.List;
public interface IoTools {
		
	static List<String> readFileNames(String filePathStr) throws IOException{
		Path filePath= Paths.get(filePathStr);
		Stream<Path> stream =  Files.list(filePath);
		//�p���o��Image Name �s��bSession?
		List<String> fileNameList = 
				stream.map(p->p.getFileName().toString()).
					collect(Collectors.toList());
		return fileNameList;
	}
 }
