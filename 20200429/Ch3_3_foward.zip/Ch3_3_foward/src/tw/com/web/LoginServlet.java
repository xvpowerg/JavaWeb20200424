package tw.com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String account = "qwer";
	private String pass = "123456";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		
		String inAccount = request.getParameter("account");
		String inPass = request.getParameter("pass");
		
		if (inAccount != null &&inPass!= null &&
				inAccount.equals(account) && inPass.equals(pass)) {
			//request ���d�� �u��OPage to Page
			request.setAttribute("account", inAccount);
			//�ϥ�RequestDispatcher�୶ ���|�ܤƺ��}
			request.getRequestDispatcher("/MainPageServlet").
						forward(request, response);
		}else {
			//�ϥ�sendRedirect�୶ �|�ܤƺ��}
			response.sendRedirect("ErrorPageServlet");
		}
		
	}

}
