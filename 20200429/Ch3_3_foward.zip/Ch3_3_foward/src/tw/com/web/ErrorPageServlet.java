package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ErrorPageServlet
 */
@WebServlet("/ErrorPageServlet")
public class ErrorPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static final String htmlTemplate = "<!DOCTYPE html>\r\n" + 
    		"<html>\r\n" + 
    		"<head>\r\n" + 
    		"<meta charset=\"UTF-8\">\r\n" + 
    		"<title>Insert title here</title>\r\n" + 
    		"</head>\r\n" + 
    		"<body>\r\n" + 
    		"<p style='color:red; font-size:60px'>%s</p>" +
    		"    <form action=\"Login.html\" method=\"get\">\r\n" + 
    		"        <button>�T�w</button>\r\n" + 
    		"    </form>\r\n" + 
    		"</body>\r\n" + 
    		"</html>";   
 
    public ErrorPageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = 
				response.getWriter();
		String newHtml = String.format(htmlTemplate, "�b���αK�X���~!");
		out.println(newHtml);
	}



}
