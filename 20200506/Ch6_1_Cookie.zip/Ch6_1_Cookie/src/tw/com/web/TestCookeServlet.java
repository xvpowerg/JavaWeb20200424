package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestCookeServlet
 */
@WebServlet("/TestCookeServlet")
public class TestCookeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private void testCookie(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException{
		// TODO Auto-generated method stub
		PrintWriter out =	response.getWriter();
		 String name = request.getParameter("account");
		 Cookie[] cookies =   request.getCookies();
		 //�w�]���Ĥ@���n�J
		 int count  = 1;
		 //�w�]���S�n�J�L ��Cookie ��null
		 boolean addToCookies = true;
		 if (cookies != null) {
			  for (Cookie cookie : cookies) {
				   if (cookie.getName().equals("user_"+name) && 
					  cookie.getValue().equals(name)) {
					   //out.println("�w��"+name+"�A���n�J");
					   addToCookies = false;
				   }else if (cookie.getName().equals("count_"+name)) {
					   count  = 
							  Integer.parseInt(cookie.getValue()) ;
					  count++;
				   }
			  }
		 }
		 out.println("�w��"+name+" "+count+"���n�J");
		 //System.out.println("Count:"+count);
		 //count ����
		Cookie countCookie = new Cookie("count_"+name,String.valueOf(count));
		countCookie.setMaxAge(60);
		response.addCookie(countCookie);
		
		 if (addToCookies) {
			 Cookie cookie = new Cookie("user_"+name,name);
			 //���� cookie�i���h�[
			 //�w�]�������s������N����
			 cookie.setMaxAge(60);
			 //�]��0�i�R��Cookie
			// cookie.setMaxAge(0);
			// �����s������N����
			 //cookie.setMaxAge(-1);
			 response.addCookie(cookie);
			 //out.println("�w��"+name+"�����n�J");
		 }
	}
	
	private String cookiesToMapKey(Cookie c) {
		return c.getName();
	}
	private String cookiesToMapValue(Cookie c) {
		return c.getValue();
	}
	
	//�ϥ�Stream
	private void testCookie2(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		PrintWriter out =	response.getWriter();
		 String name = request.getParameter("account");
		 Optional<Cookie[]> cookieOption = 
				 Optional.ofNullable(request.getCookies());		 
		 //�w�]���Ĥ@���n�J
		 int count  = 1;
		 Map<String,String> cookisMap = new HashMap();
		 if (cookieOption.isPresent()){
			 Cookie[] values =   cookieOption.get();
			 Stream<Cookie>	cookieStr= Stream.of(values);
			 cookisMap = cookieStr.filter(cookie->
			 cookie.getName().equals("user_"+name) ||
			 cookie.getName().equals("count_"+name)).
					collect(Collectors.toMap(this::cookiesToMapKey,
									 this::cookiesToMapValue));
		 }
		 
			if (cookisMap.containsKey("count_"+name)) {
				 String countStr =  cookisMap.get("count_"+name);
				 count = Integer.parseInt(countStr);
				 count++;
				 out.println("�w��"+name+" "+count+"���n�J"); 
			}else {
				Cookie userCookie = new Cookie("user_"+name,name);
				response.addCookie(userCookie);
				 out.println("�D�`�w��"+name+"�[�J�ζ�"); 
			}
			Cookie countCookie = new Cookie("count_"+name,String.valueOf(count));
			response.addCookie(countCookie);
	}
	
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html;charset=UTF-8");
		// testCookie( request,response);
		 testCookie2(request,response);
		 
	}

}
