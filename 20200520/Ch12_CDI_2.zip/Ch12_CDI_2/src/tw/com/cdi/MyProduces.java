package tw.com.cdi;

import javax.enterprise.inject.Produces;
import javax.inject.Named;

import java.util.Map;
import java.util.HashMap;
public class MyProduces {
	public static final String GROUP_SCORE = "groupScore";
	public static final String GROUP_PRICE = "groupPrice";

	@Produces
	private float[][] postion = {{10,20},{35,71},{66,28}  }; 
	@Produces
	@Named(GROUP_SCORE)
	private Map<String,Integer> groupScore() {
		Map<String,Integer> groupMap = new HashMap<>();
		groupMap.put("Ken", 100);
		groupMap.put("Vivin", 72);
		groupMap.put("Lindy", 98);
		return groupMap;
	}
	@Named(GROUP_PRICE)
	@Produces
	private Map<String,Integer> groupPrice() {
		Map<String,Integer> priceMap = 
						new HashMap<>();
		priceMap.put("pimax5k", 22800);
		priceMap.put("Htc Vivie ", 25000);
		priceMap.put("Steam View ", 35000);
		return priceMap;
	
	}
	
}
