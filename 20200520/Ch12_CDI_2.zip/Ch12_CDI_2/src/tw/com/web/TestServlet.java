package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.cdi.MyProduces;

/**
 * Servlet implementation class TestServlet
 */
@WebServlet("/TestServlet")
public class TestServlet extends HttpServlet {
	private static final String GROUP_NAME = 
			MyProduces.GROUP_SCORE;

	private static final long serialVersionUID = 1L;
     @Inject
	private float[][] myPostion;
    @Named(GROUP_NAME)
    @Inject
    private Map<String,Integer> myGroupMap;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out =   response.getWriter();
		out.println(myPostion[0][0]);
		out.println(myGroupMap);
	}



}
