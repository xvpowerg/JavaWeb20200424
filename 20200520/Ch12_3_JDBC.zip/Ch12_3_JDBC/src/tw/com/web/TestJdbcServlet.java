package tw.com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;

/**
 * Servlet implementation class TestJdbcServlet
 */
@WebServlet("/TestJdbcServlet")
public class TestJdbcServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String url = "jdbc:mysql://localhost:3306/testdb?serverTimezone=CST&useSSL=false&allowPublicKeyRetrieval=true";
		String user = "root";
		String password = "123456";
		
	     try(Connection con= DriverManager.getConnection(url, user, password)){
	    	 
	    	 Statement stm = con.createStatement();
	    	 stm.executeUpdate("INSERT INTO person(name,age) VALUES('Vivin',10)");
	    	 
	    	 
	     }catch(SQLException ex) {
	    	 System.out.println("SQLException:"+ex);
	     }
		response.getWriter().append("Served at: ").append(request.getContextPath());	
	}



}
