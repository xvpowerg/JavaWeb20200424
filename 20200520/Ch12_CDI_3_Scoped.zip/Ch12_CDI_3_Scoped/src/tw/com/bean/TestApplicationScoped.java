package tw.com.bean;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class TestApplicationScoped {
	private String name= "Application Name";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "TestApplicationScoped [name=" + name + "]";
	}
		

}
