package tw.com.bean;

import javax.enterprise.context.RequestScoped;

@RequestScoped
public class TestRequestScoped {
	private String name= "Request Empty";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "TestRequestScoped [name=" + name + "]";
	}
	
	
}
