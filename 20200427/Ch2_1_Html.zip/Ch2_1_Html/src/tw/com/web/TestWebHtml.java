package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestWebHtml
 */
@WebServlet("/TestWebHtml")
public class TestWebHtml extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static final String tmpletHtml = "<!DOCTYPE html>\r\n" + 
			"<html>\r\n" + 
			"<head>\r\n" + 
			"<meta charset=\"UTF-8\">\r\n" + 
			"<title>Insert title here</title>\r\n" + 
			"</head>\r\n" + 
			"<body>\r\n" + 
			"<H%1$d>%2$s</H%1$d>" + 
			"</body>\r\n" + 
			"</html>"; 
	
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    //��X�s�X��UTF-8
	    response.setContentType("text/html;charset=UTF-8");
	    PrintWriter out =
	    		   response.getWriter();

	   String number =  request.getParameter("number");
	   if (number !=  null) {
		   try {
			   int n = Integer.parseInt(number);
			    for (int i =0 ; i<n ; i++) {
			    	 String value = ( (char)('A'+i) )+"";
			    	 String newHtml = 
			    			 String.format(tmpletHtml, i+1,value );
			       out.println(newHtml);
			    }
		   }catch(NumberFormatException ex) {
			   out.println("�����T���Ʀr�榡!");
		   }

	   }else {
		   out.println("�п�J�Ʀr");
	   }
	   
	  
	}


}
