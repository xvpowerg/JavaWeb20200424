package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.com.bean.Product;

/**
 * Servlet implementation class ShoppingCartServlet
 */
@WebServlet("/ShoppingCartServlet")
public class ShoppingCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Map<String,Product> productMap = new HashMap();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShoppingCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    public void init() {
    	productMap.put("1", new Product("xBOx",12000));
    	productMap.put("2", new Product("PS5",25000));
    	productMap.put("3", new Product("Switch",8900));
    }
    //�n�`�N������w��
    private Product fetchProduct(String key) {
//    	Product prod = productMap.get(key);
//    	Product newProd = new Product(prod.getName(),prod.getPrice());
//    	return newProd;
     	return productMap.get(key);
    }
    
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
        response.setContentType("text/html;charset=UTF-8");
       PrintWriter out = response.getWriter();
       //�p�GSession���s�bgetSession��null
		HttpSession session =  request.getSession(false);
		if (session == null  ||
				session.getAttribute("account") == null ) {
			out.println("�еn�J��b�ʪ�!");
		}else {
			//getParameterMap �]�i���oParameter
			Map<String,String[]> map =  request.getParameterMap();
			for (int i =1;i<=3;i++) {
				if (map.containsKey("prd"+i)) {
					String[] value = map.get("prd"+i);
					if (value.length > 0 ) {
						Product p = fetchProduct(value[0]);
						out.println("���~:"+p.getName()+" ���B:"+p.getPrice());	
					}
				}
			}
			
		}
		
	}


}
