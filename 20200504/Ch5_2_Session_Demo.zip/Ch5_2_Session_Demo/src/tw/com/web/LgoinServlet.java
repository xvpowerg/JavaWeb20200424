package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LgoinServlet
 */
@WebServlet("/LgoinServlet")
public class LgoinServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String account = "qwer";
	private static String password = "123456";
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LgoinServlet() {
        super();
    }

	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
	  PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		 String account = request.getParameter("account");
		  String  password = request.getParameter("pass");
		if (account.equals(LgoinServlet.account) &&
				password.equals(LgoinServlet.password)) {
			session.setAttribute("account", account);
			response.sendRedirect("ShoppingCar.html");
		}else {
			out.println("�n�J����!�Ъ�^�W��");
		}
		
		
		
	
	}

}
