package tw.com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class TestSessionServlet
 */
@WebServlet("/TestSessionServlet")
public class TestSessionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public TestSessionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		//getSession ���@�Ѽ� ���]��true �ثe�S��Session�|���A�إ� �w�]
		//getSession ���@�Ѽ� ���]��false �ثe�S��Session���|���A�إ�
		HttpSession session = request.getSession();
		session.setAttribute("name", "Vivin");
		session.setAttribute("age", 26);
		response.getWriter().append("Served at:").
		   append(request.getContextPath());
		
	}

	

}
