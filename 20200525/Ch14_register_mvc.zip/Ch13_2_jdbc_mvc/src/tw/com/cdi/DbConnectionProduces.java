package tw.com.cdi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.enterprise.inject.Disposes;
import javax.enterprise.inject.Produces;

public class DbConnectionProduces {
	@Produces
	private Connection getDbConnection()throws SQLException {
		String url = "jdbc:mysql://localhost:3306/testdb?serverTimezone=CST&useSSL=false&allowPublicKeyRetrieval=true";
		String user = "root";
		String password = "123456";
		Connection con= DriverManager.
	    		 getConnection(url, user, password);
		
		
		return con;
	}
	
	//@Disposes ��Produces���Ѫ�����QGC���e �|�I�s
	private void closeConnection(@Disposes Connection con)throws SQLException  {
		con.close();
	}
}
