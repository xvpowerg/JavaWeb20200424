package tw.com.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.com.bean.Person;
import tw.com.db.PersonControlDB;

/**
 * Servlet implementation class ShowPersonServlet
 */
@WebServlet("/ShowPersonServlet")
public class ShowPersonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Inject
	PersonControlDB pDb;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowPersonServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
			  int personId = (Integer)request.getAttribute("personId");			
			  try {
				    Person p =  pDb.queryPerson(personId);
			    	session.setAttribute("person", p);
			    	response.sendRedirect("personInfo.jsp");     
			  }catch(SQLException ex) {
				  System.out.println(ex);
			  }
	}

}
