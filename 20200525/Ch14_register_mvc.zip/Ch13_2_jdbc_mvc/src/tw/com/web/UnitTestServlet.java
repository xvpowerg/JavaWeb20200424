package tw.com.web;

import java.io.IOException;
import java.sql.SQLException;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.bean.Login;
import tw.com.bean.Person;
import tw.com.db.PersonControlDB;

/**
 * Servlet implementation class UnitTestServlet
 */
@WebServlet("/UnitTestServlet")
public class UnitTestServlet extends HttpServlet {
		@Inject
		PersonControlDB pDB;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UnitTestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    private void  register() {
		Person p1 = new Person();
		p1.setName("Lindy");
		p1.setAge(21);
		Login login = new Login();
		login.setAccount("zxcv");
		login.setPassword("123456");
		//try {
//			p1 = pDB.createPerson(p1);
//			pDB.createLogin(login, p1);
			pDB.register(login, p1);
//		} catch (SQLException e) {
//			System.out.println(e);
//		}
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

	}



}
