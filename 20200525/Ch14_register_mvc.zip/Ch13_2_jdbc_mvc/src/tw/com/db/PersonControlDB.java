package tw.com.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;

import tw.com.bean.Login;
import tw.com.bean.Person;

@RequestScoped
public class PersonControlDB {
	@Inject
	private Connection con;

	public int login(Login login) throws SQLException {
		PreparedStatement ps = con
				.prepareStatement("SELECT  account,password," + "person_id FROM testdb.login_table WHERE account=?");
		ps.setString(1, login.getAccount());

		int personId = -1;
		ResultSet res = ps.executeQuery();
		if (res.next() == false)
			return personId;
		
		Login queryLogin = new Login();
		queryLogin.setAccount(res.getString("account"));
		queryLogin.setPassword(res.getString("password"));
		
		if (queryLogin.check(login))
			personId = res.getInt("person_id");

		return personId;
	}

	public Person queryPerson(int personId) throws SQLException {
		Statement stm = con.createStatement();
		ResultSet rs = stm.executeQuery("SELECT * FROM person WHERE id = " + personId);
		rs.next();
		String name = rs.getString("name");
		int age = rs.getInt("age");
		Person p = new Person();
		p.setName(name);
		p.setAge(age);
		p.setId(personId);
		return p;
	}

	private Person createPerson(Person person) throws SQLException {
		Statement stm = con.createStatement();
		int pId = -1;
		String sql = "INSERT INTO person(name,age) VALUES('%s',%d)";
		sql = String.format(sql, person.getName(),person.getAge());
		System.out.println("createPerson:"+sql);
		//���oPerson��ID
		 stm.executeUpdate(sql,
				 Statement.RETURN_GENERATED_KEYS);
		ResultSet keyRes =stm.getGeneratedKeys();
		if (keyRes.next()) {
			System.out.println("Key:"+keyRes.getInt(1));
			pId = keyRes.getInt(1);
		}
		
		Person p = new Person();
		p.setAge(person.getAge());
		p.setName(person.getName());
		p.setId(pId);

	   return p;	 
	}
	private void createLogin(Login login,Person person) throws SQLException {
		Statement stm = con.createStatement();
		String sql = "INSERT INTO login_table(account,password,person_id) VALUES('%s','%s',%d)";
		sql = String.format(sql,
				login.getAccount(),login.getPassword(),
				person.getId());
		System.out.println("createLogin:"+sql);
		int count = stm.executeUpdate(sql);
	}
	
	public boolean register(Login login,Person person){
		try {
			person =createPerson(person);
			createLogin(login, person);
		} catch (SQLException e) {
			System.out.println(e);
			return false;
		}
		return true;
		
	}

}
