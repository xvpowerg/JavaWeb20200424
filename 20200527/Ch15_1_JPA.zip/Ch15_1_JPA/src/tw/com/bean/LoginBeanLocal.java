package tw.com.bean;

import javax.ejb.Local;

import tw.com.entity.Login;
import tw.com.entity.Person;

@Local
public interface LoginBeanLocal {
	void createPerson(Login login);
	void queryByAccount(String account);
}
