package tw.com.bean;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import tw.com.entity.Login;
import tw.com.entity.Person;

/**
 * Session Bean implementation class LoginBean
 */
@Stateless
public class LoginBean implements LoginBeanLocal {
	@Inject
	 private EntityManager em;
    /**
     * Default constructor. 
     */
    public LoginBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public void createPerson(Login login) {
		em.persist(login);
	}

	@Override
	public void queryByAccount(String account) {
		TypedQuery<Login> query =
				em.createNamedQuery("findLoginByAccount",Login.class);
		query.setParameter("account", account);
		Login logn =  query.getSingleResult();
		System.out.println("logn:"+logn);
	}

}
