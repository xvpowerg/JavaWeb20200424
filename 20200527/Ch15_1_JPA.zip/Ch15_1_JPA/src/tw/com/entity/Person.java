package tw.com.entity;

import java.io.Serializable;
import javax.persistence.*;
import javax.validation.GroupSequence;

/**
 * Entity implementation class for Entity: Person
 *
 */
@Entity
public class Person implements Serializable {

	private static final long serialVersionUID = 1L;

	public Person() {
		super();
	}

	@Id
	@GeneratedValue
	private int id;
	@Column(name="p_name",length =20 )
	private String name;
	private int age;

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
