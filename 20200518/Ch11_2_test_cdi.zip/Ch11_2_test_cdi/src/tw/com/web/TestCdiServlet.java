package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.annotation.PersonKen;
import tw.com.bean.Book;
import tw.com.bean.Fly;
import tw.com.bean.Person;

//CDI Contexts and Dependency Injection
@WebServlet("/TestCdiServlet")
public class TestCdiServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Inject
	private Book book;
	//�p�Gjava�M�פ��u���@�չ�@Fly������ ����@Inject�|�۰ʧP�_
	@Inject 
	private Fly flyObj;
	@Named("Xiaoming")
    @Inject
    private Person personObj;
    @PersonKen
    @Inject
    private Person personKen;
	@Inject
	private String[] myNames;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestCdiServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 response.setContentType("text/html;charset=UTF-8");
		 PrintWriter out =   response.getWriter();
		 out.println("Served at: "+book);
		 out.println(" Fly at: "+flyObj);
		 out.println("PersonObj at: "+personObj);
		 out.println("PersonKen at: "+personKen);
		 out.println("MyNames at: "+myNames[1]);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
