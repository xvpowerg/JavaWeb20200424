package tw.com.bean;

import javax.inject.Named;

@Named("Xiaoming")
public class Xiaoming implements Person{
	private String name = "�p��";
	private int age = 20;
	
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
		
	}

	@Override
	public int getAge() {
		// TODO Auto-generated method stub
		return age;
	}

	@Override
	public void setAge(int age) {
		// TODO Auto-generated method stub
		this.age = age;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.getName()+":"+this.getAge();
	}

	
}
