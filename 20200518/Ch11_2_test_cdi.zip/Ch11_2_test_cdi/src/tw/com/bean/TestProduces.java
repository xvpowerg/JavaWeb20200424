package tw.com.bean;

import javax.enterprise.inject.Produces;

public class TestProduces {

	@Produces
	private String[] names = {"Vivin","Iris","Join"};
	
}
