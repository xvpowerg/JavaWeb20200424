package tw.com.bean;

public class Bird implements Fly{

	@Override
	public void flying() {
		System.out.println("Bird flying flying");
	}
}
