package tw.com.bean;

import tw.com.annotation.PersonKen;

@PersonKen
public class Ken implements Person{
	private String name = "Ken";
	private int age = 62;
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public void setName(String name) {
		// TODO Auto-generated method stub
		this.name = name;
	}

	@Override
	public int getAge() {
		// TODO Auto-generated method stub
		return age;
	}

	@Override
	public void setAge(int age) {
			this.age = age;
		
	}

	@Override
	public String toString() {
		return name+":"+age;
	}
	

}
