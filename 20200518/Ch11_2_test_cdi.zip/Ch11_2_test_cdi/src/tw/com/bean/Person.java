package tw.com.bean;

public interface Person {
	 String getName();
	 void setName(String name);
	int getAge();
	void  setAge(int age);
	
}
