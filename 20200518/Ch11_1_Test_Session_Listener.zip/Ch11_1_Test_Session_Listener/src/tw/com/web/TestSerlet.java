package tw.com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class TestSerlet
 */
@WebServlet("/TestSerlet")
public class TestSerlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestSerlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String remove = request.getParameter("remove");
		String account = request.getParameter("account");
		String remAccount = request.getParameter("remAccount");
		String repAccount = request.getParameter("repAccount");
		HttpSession session = request.getSession();
		//���]add�ݩʬOaccount �i�D��XXX�n�J���\
		//���]�������ݩʳ]�w�Oaccount �i�D��XXX�w�n�X
		if (account != null) {
			session.setAttribute("account", account);
		}else if(remAccount != null) {
			session.removeAttribute("account");
		}else if(repAccount != null) {
			session.setAttribute("account", repAccount);
		}
		if (Boolean.parseBoolean(remove)) {
			session.invalidate();
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}



}
