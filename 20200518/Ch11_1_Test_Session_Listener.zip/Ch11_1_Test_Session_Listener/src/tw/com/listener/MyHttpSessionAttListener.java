package tw.com.listener;

import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;

public class MyHttpSessionAttListener implements HttpSessionAttributeListener {

	@Override
	public void attributeAdded(HttpSessionBindingEvent event) {
		// TODO Auto-generated method stub
		if ( event.getName().equals("account")) {
			//String account = (String)event.getSession().getAttribute("account");
			
			System.out.println(event.getValue()+"�n�J���\");
		}
		System.out.println("attributeAdded!!");
	}

	@Override
	public void attributeRemoved(HttpSessionBindingEvent event) {
		// TODO Auto-generated method stub
		if (event.getName().equals("account")) {
		System.out.println(	event.getValue());
		//event.getSession().getAttribute("account") �|�Onull �ҥH�|���ͨҥ~
			//String account = event.getSession().getAttribute("account").toString();
			System.out.println(event.getValue()+"�n�X���\");
		}
		//System.out.println("attributeRemoved!!");
	}

	@Override
	public void attributeReplaced(HttpSessionBindingEvent event) {
		// TODO Auto-generated method stub
		//attributeReplaced event.getValue() ���o���ק�e���ƭ�
		System.out.println("attributeReplaced!!:"+event.getValue());
		//event.getSession().getAttribute("account") ���o�л\�᪺�ƭ�
		System.out.println("attributeReplaced!!:2"+event.getSession().getAttribute("account"));  
	}
	
}
