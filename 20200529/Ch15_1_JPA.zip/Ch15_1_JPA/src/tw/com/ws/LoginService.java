package tw.com.ws;

import javax.ejb.EJB;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.fasterxml.jackson.databind.ObjectMapper;

import tw.com.bean.LoginBeanLocal;
import tw.com.entity.Login;
import tw.com.entity.Person;

@Path("login")
@Produces(MediaType.APPLICATION_JSON)
public class LoginService {
	@EJB
	private LoginBeanLocal loginBean; 
	@POST
	@Path("create")
	public String createLogin(@FormParam("name") String name,
			@DefaultValue("0")
			@FormParam("age") int age,
			@FormParam("account") String account,
			@FormParam("password") String pass) {
		
		Person p = new Person();
		p.setName(name);
		p.setAge(age);
		Login login = new Login();
		login.setAccount(account);
		login.setPassword(pass);
		login.setPerson(p);
		try {
			loginBean.createPerson(login);
		}catch(Exception ex) {
			return "{\"status\":false}";
		}		
		return "{\"status\":true}";
	}
	@POST
	public String login(@FormParam("account") String account,
						@FormParam("password") String password) {
		
	     try {
	    	 Login login = loginBean.queryByAccount(account);
	    	  if (login.getPassword().equals(password)) {
	    		  ObjectMapper mapper = new ObjectMapper();
	    		  String json = mapper.writeValueAsString(login);
	  	    	 return json;
	  	     } 
	     }catch(Exception ex) {
	    	 
	     }
	  
		return "{\"status\":false}";
	}
	
}
