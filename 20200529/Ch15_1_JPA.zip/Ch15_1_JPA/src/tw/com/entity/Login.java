package tw.com.entity;

import java.io.Serializable;
import javax.persistence.*;
import javax.validation.GroupSequence;

/**
 * Entity implementation class for Entity: Login
 *
 */
@Entity
@Table(name="login_table")
@NamedQueries({	
	@NamedQuery(name="findLoginByAccount",
			query ="SELECT myLogin FROM Login myLogin WHERE myLogin.account=:account")	
})
public class Login implements Serializable {
	public Login() {
		super();
	}
	@Id
	@GeneratedValue
	private int id;
	private String account;
	private String password;
	@OneToOne(cascade = CascadeType.PERSIST)
	private Person person;
	public int getId() {
		return id;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	
	
   
}
