package tw.com.web;

import java.io.IOException;

import javax.ejb.EJB;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import tw.com.bean.LoginBeanLocal;
import tw.com.entity.Login;
import tw.com.entity.Person;

/**
 * Servlet implementation class TestJpaServlet
 */
@WebServlet("/TestJpaServlet")
public class TestJpaServlet extends HttpServlet {
	@EJB
	private LoginBeanLocal lgoinBean; 
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestJpaServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		Person p1 = new Person();
		p1.setName("Ken");
		p1.setAge(25);
		Login login = new Login();
		login.setAccount("qwer");
		login.setPassword("123456");
		login.setPerson(p1);
		
		lgoinBean.createPerson(login);
		lgoinBean.queryByAccount("qwer");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
