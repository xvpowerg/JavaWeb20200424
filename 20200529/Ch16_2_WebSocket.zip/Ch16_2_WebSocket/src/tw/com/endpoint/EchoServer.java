package tw.com.endpoint;

import javax.websocket.OnMessage;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/echo")
public class EchoServer {
	
	@OnMessage
	public String echo(String mssage) {
		System.out.println("EchoServer!!");
		return "OK!!!"+mssage;
	}
}
