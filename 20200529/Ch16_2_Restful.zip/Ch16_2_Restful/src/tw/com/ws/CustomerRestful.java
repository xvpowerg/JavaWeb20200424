package tw.com.ws;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.PATCH;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("test")
//���ܩҦ���k�^�Ǫ����欰JSON
@Produces(MediaType.APPLICATION_JSON)
public class CustomerRestful {
//JOSN
	//GET �d�� 
	@GET
	public String testHello() {
		String json ="{\"value\":\"Hello\"}";
		return json;
	}
	
	@GET
	@Path("numbers")
	public String queryNumbers(@QueryParam("end") int end) {
		StringBuffer sb = new StringBuffer();
		sb.append("[");
		for (int i = 1;i<=end;i++) {
			sb.append(i);
			if (i  < end) 	sb.append(",");
		}		
		sb.append("]");		
		return sb.toString();
	}
	@POST
	public String createLogin(@FormParam("account")String account,
			@FormParam("password")String pass) {
		String json =String.format("{\"account\":\"%s\" ,\"password\":\"%s\"}", 
				account,pass) ;
		return json;
	}
	@PATCH
	public String update(
			@DefaultValue("empty")
			@FormParam("account") String account,
			@DefaultValue("iipipo")
			@FormParam("password") String password) {
		String json =String.format("{\"account\":\"%s\" ,\"password\":\"%s\"}", 
				account,password) ;
		return json;
	}
	
	//POST �s�W
	//DELETE �R��
	//PATCH ��s
	
	
}
