package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ShowMsge
 */
@WebServlet("/ShowMsgeServlet")
public class ShowMsgeServlet extends HttpServlet {
	
   private static final String htmlTemplate = "<!DOCTYPE html>\r\n" + 
			"<html>\r\n" + 
			"<head>\r\n" + 
			"<meta charset=\"UTF-8\">\r\n" + 
			"<title>Insert title here</title>\r\n" + 
			"<script>\r\n" + 
			"	function testInterval(){\r\n" + 
			"		setInterval(reload,3000);\r\n" + 
			"	}\r\n" + 
			"\r\n" + 
			"	function reload(){\r\n" + 
			"		location.reload();\r\n" + 
			"	}\r\n" + 
			"	testInterval();\r\n" + 
			"</script>\r\n" + 
			"</head>\r\n" + 
			"<body>\r\n" + 
			"<p>%s</p>\r\n" + 
			"</body>\r\n" + 
			"</html>";
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowMsgeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 response.setContentType("text/html;charset=UTF-8");
		 PrintWriter out = response.getWriter();
		 String msg = (String)
				 getServletContext().getAttribute("msg");
		 msg = msg==null?"":msg;
			 String newHtml =String.format(htmlTemplate, msg); 
			 out.println(newHtml);
		 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
