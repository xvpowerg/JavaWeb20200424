/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_1_20200519;

/**
 *
 * @author xvpow
 */
public class Student {
    private String name;
    private int age;
    Student(String name,int age){
	this.name = name;
	this.age = age;
    }
    public String getName(){
	return name;
    }
    public int getAge(){
	return age;
    }
    public String toString(){
	return name+":"+age;
    }
    
    public boolean equals(Object obj){
	if (obj == null || obj instanceof Student == false){
	    return false;
	}
	Student tmpSt = (Student)obj;	
	return name.equals(tmpSt.name) && age == tmpSt.age;
	
    }
}
