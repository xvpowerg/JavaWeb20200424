/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_1_20200519;
import java.util.List;
import java.util.ArrayList;
public class Ch16_5 {
  static void printList(List<Student> stList){
      System.out.println("==================================");
      stList.forEach(st->System.out.print(st+" "));
      System.out.println();
  }
    public static void main(String[] args) {
	
	Student st1 = new Student("Ken",25);
	Student st2 = new Student("Vivin",13);
	Student st3 = new Student("Lindy",61);
	Student deleteObj = new Student("Vivin",13);
	Student findObj = new Student("Lindy",61);
	//請幫我完成deleteObj.equals(st2) 因該回傳true
	System.out.println(deleteObj.equals(st2));
	
	List<Student> stList = new ArrayList<>();
	stList.add(st1);
	stList.add(st2);
	stList.add(st3);
	printList(stList);
	stList.remove(deleteObj);//會使用equals做比較 如果回傳true才會remove
	printList(stList);
	int index = stList.indexOf(findObj);
	boolean b1 = stList.contains(findObj);
	System.out.println("Index:"+index);
	System.out.println("b1:"+b1);
    }
    
}
