/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_1_20200519;
import java.util.ArrayList;
import java.util.List;
public class Ch16_1 {
    //List 是一組沒有大小限制的陣列
    //常用的List是 ArrayList LinkedList
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	List listArray = new ArrayList();
	//加入數值 進入List
	listArray.add("Ken");
	listArray.add("Vivin");
	listArray.add(null);
	listArray.add("Lindy");	
//	for (int i= 0;i < listArray.size();i++){
//	    System.out.println(listArray.get(i));
//	}
//foreach 迴圈
//	for (Object s : listArray){
//	    System.out.println(s);
//	}
//foreach 方法
	listArray.forEach(n->System.out.println(n));
	
    }
    
}
