/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_1_20200519;
import java.util.ArrayList;
import java.util.List;
public class Ch16_2 {
    static int sum = 0;
    public static void main(String[] args) {
	List myList = new ArrayList();
	
	myList.add(20);
	myList.add(70);
	myList.add(95);
	myList.add(62);
	
	
	int g = 10; 
	myList.forEach(n->{
	    Integer v = (Integer)n;
	    sum += v;
	});
	
	System.out.println(sum);
	
    }
    
}
