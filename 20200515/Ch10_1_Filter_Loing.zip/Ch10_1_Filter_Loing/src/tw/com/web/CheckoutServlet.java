package tw.com.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.com.bean.Product;

import java.util.stream.Collectors;
import java.util.stream.Stream;
/**
 * Servlet implementation class CheckoutServlet
 */
@WebServlet("/order/CheckoutServlet")
public class CheckoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckoutServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 HttpSession session =   request.getSession();
		 List<Product> pList = (List)session.getAttribute("pList");
		String[] items =  request.getParameterValues("item");
		Stream<String> itStream =  Stream.of(items);
		
	List<Product> orderList = 	itStream.map(i->{
			int idx = Integer.parseInt(i);	
			return pList.get(idx);
		}).collect(Collectors.toList());
	session.setAttribute("orderList", orderList);
	response.sendRedirect("checkout.jsp");	
	}

}
