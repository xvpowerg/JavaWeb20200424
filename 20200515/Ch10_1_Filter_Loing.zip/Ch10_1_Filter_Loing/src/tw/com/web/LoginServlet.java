package tw.com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.com.verify.VerifyIdentity;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String account = request.getParameter("account");
		String password = request.getParameter("pass");
		HttpSession session = request.getSession();
		//���հ��ݬݥi�blogin.jsp��ܵn�J���� 
		if (VerifyIdentity.login(account, password)) {
			session.setAttribute("account", account);
			//ShoppingCar
			request.getRequestDispatcher("order/ShoppingCartServlet").
					forward(request, response);;
		}else {
		   //login.jsp
			session = request.getSession();
			session.setAttribute("errorMsg", "�n�J����");
			response.sendRedirect("login.jsp");
		}
		
	}

}
