package tw.com.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.com.bean.Product;
import tw.com.bean.ProductSrc;

/**
 * Servlet implementation class ShoppingCartServlet
 */
@WebServlet("/order/ShoppingCartServlet")
public class ShoppingCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShoppingCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String account = (String)session.getAttribute("account");//????
		if (account != null) {
			List<Product> pList=ProductSrc.getProducts(account);
			session.setAttribute("pList", pList);
			response.sendRedirect("shoppingCar.jsp");
		}
	
		
	}

}
