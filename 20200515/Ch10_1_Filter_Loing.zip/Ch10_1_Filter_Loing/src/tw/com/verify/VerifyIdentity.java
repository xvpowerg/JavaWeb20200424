package tw.com.verify;

public class VerifyIdentity {
		//�b�� ��K�X �s�b��Ʈw��O�o�n�[�K
	public static boolean login(String account,String password) {
		String defAcc = "qwer";
		String defPass = "12345";
		if (defAcc.equals(account) && defPass.equals(password)) {
			return true;
		}
		
		return false;
	}
}
