package tw.com.bean;

import java.util.ArrayList;
import java.util.List;

public class ProductSrc {
	
    public static List<Product> getProducts(String account){
    	
    	List<Product> list = new ArrayList<>();
    	
    	Product p1 = new Product("Apple iPhone12",25000);
    	Product p2 = new Product("Htc Vivie",26000);
    	Product p3 = new Product("Pimax",27000);
    	Product p4 = new Product("Switch",7800);
    	Product p5 = new Product("Ps5",23000);
    	
    	list.add(p1);
    	list.add(p2);
    	list.add(p3);
    	list.add(p4);
    	list.add(p5);
    	return list;
    	
    }
}
