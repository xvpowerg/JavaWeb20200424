package tw.com.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;

@RequestScoped
public class PersonControlDB {
	@Inject
	private Connection con;
	public int login(String account,String password) throws SQLException{
   	 PreparedStatement ps = 
			 con.prepareStatement("SELECT  account,password,"
			+ "person_id FROM testdb.login_table WHERE account=?");
	 ps.setString(1, account);
	 int personId =-1;
	  ResultSet res=  ps.executeQuery();
	  if (res.next()) {
		 if (res.getString("password").equals(password) && 
				 res.getString("account").equals(account)) {
			 personId = res.getInt("person_id");
		 }	    		
	  }
		return personId;
	}
	
	public void queryPerson(int personId) {
		
	}

}
