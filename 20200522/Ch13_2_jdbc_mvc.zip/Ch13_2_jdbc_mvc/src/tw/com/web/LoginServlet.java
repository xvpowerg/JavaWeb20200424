package tw.com.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.com.db.PersonControlDB;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	@Inject
	PersonControlDB personDb;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String loginAccount = request.getParameter("account");;
		String loginPassword = request.getParameter("password");
		HttpSession session = request.getSession();
		int personId = -1;
	     try{
	    	 personId = personDb.login(loginAccount, loginPassword);	    	 	    	
	    	  if (personId == -1) {
	    		  session.setAttribute("errorMsg", "�n�J����"); 
	    		  response.sendRedirect("login.jsp");
	    	  }else {
	    		session.removeAttribute("errorMsg");
	    		request.setAttribute("personId",personId);
	    		request.getRequestDispatcher("/ShowPersonServlet").
	    		  				forward(request, response);
	    	  } 
	     }catch(SQLException ex) {
	    	 System.out.println("SQLException:"+ex);
	     }	
	}

}
