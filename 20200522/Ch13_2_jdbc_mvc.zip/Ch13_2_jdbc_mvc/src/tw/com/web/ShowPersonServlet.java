package tw.com.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ShowPersonServlet
 */
@WebServlet("/ShowPersonServlet")
public class ShowPersonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowPersonServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String url = "jdbc:mysql://localhost:3306/testdb?serverTimezone=CST&useSSL=false&allowPublicKeyRetrieval=true";
		String user = "root";
		String password = "123456";
		HttpSession session = request.getSession();
		   try(Connection con= DriverManager.
		    		 getConnection(url, user, password)){
			   Statement stm=  con.createStatement();
			   int personId = (Integer)request.getAttribute("personId");
	    		ResultSet rs =  stm.executeQuery("SELECT * FROM person WHERE id = "+personId);
	    		rs.next();
	    		String name = rs.getString("name");
	    		int age = rs.getInt("age"); 
	    		session.setAttribute("name", name);
	    		session.setAttribute("age", age);
	    		response.sendRedirect("personInfo.jsp");   
		   }catch(SQLException ex) {
		    	 System.out.println("SQLException:"+ex);
		     }
		
		
	}

}
