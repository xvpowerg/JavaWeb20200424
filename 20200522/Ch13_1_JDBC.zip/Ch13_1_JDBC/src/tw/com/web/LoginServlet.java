package tw.com.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String url = "jdbc:mysql://localhost:3306/testdb?serverTimezone=CST&useSSL=false&allowPublicKeyRetrieval=true";
		String user = "root";
		String password = "123456";
	
		String loginAccount = request.getParameter("account");;
		String loginPassword = request.getParameter("password");
		HttpSession session = request.getSession();
		boolean isFaill = true;
		int personId = -1;
		
	     try(Connection con= DriverManager.
	    		 getConnection(url, user, password)){
	    	 
	    	 PreparedStatement ps = 
	    			 con.prepareStatement("SELECT  account,password,"
	    			+ "person_id FROM testdb.login_table WHERE account=?");
	    	 ps.setString(1, loginAccount);
	    	  ResultSet res=  ps.executeQuery();
	    	  if (res.next()) {
	    		 personId = res.getInt("person_id");
	    		 
	    		 if (res.getString("password").equals(loginPassword) && 
	    				 res.getString("account").equals(loginAccount)) {
	    			 isFaill = false;
	    		 }	    		
	    	  }
	    	  	
	    	  if (isFaill) {
	    		  session.setAttribute("errorMsg", "�n�J����"); 
	    		  response.sendRedirect("login.jsp");
	    	  }else {
	    		session.removeAttribute("errorMsg");
	    		request.setAttribute("personId",personId);
	    		request.getRequestDispatcher("/ShowPersonServlet").
	    		  				forward(request, response);
	    	  }
	   
	     }catch(SQLException ex) {
	    	 System.out.println("SQLException:"+ex);
	     }
	
	}

}
